const pets = [
  {
    id: 0,
    pet_name: "loki",
    species: "dog",
    eating_habit: "omnivore",
    image_url: "dog1.jpg",
  },
  {
    id: 1,
    pet_name: "Snow",
    species: "cat",
    eating_habit: "omnivore",
    image_url: "cat1.jpg",
  },
  {
    id: 2,
    pet_name: "Georgie",
    species: "dog",
    eating_habit: "carnivore",
    image_url: "dog2.jpg",
  },
  {
    id: 3,
    pet_name: "Percy",
    species: "cat",
    eating_habit: "omnivore",
    image_url: "cat2.jpg",
  },
  {
    id: 4,
    pet_name: "Bumble",
    species: "rabbit",
    eating_habit: "omnivore",
    image_url: "rabbit1.jpg",
  },
];

module.exports = { pets };
