const pets = [
  {
    id: 0,
    species: "dog",
    eating_habit: "carnivore",
    pet_name: "Brownie",
  },
  {
    id: 0,
    species: "cat",
    eating_habit: "carnivore",
    pet_name: "Oreo",
  },
  {
    id: 0,
    species: "rabbit",
    eating_habit: "herbivore",
    pet_name: "Hunter",
  },
  {
    id: 0,
    species: "pig",
    eating_habit: "omnivore",
    pet_name: "Chris-P",
  },
  {
    id: 0,
    species: "dog",
    eating_habit: "carnivore",
    pet_name: "cloe",
  },
];

module.exports = { pets };
